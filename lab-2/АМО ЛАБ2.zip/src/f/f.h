// f.h
#ifndef F_H
#define F_H

extern double A;
extern double B;
extern double m1;
extern double M1;
extern double LAMBDA;
extern double Q;

double f(double x);

#endif